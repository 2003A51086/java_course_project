package com.mycompany.jtable_demo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DELL
 */
public class Row {
    private static int row;
    public static int getRow(){
        return row;
    }
    public static void setRow(){
        row++;
    }
    public static void setRow( int temp){
        row= temp;
    }

}
